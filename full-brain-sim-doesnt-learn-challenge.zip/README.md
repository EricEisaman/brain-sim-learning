# Brain Network Learning Visualization

A real-time neural network simulation demonstrating Hebbian learning with Oja's rule. Watch as the network learns to associate input patterns with specific outputs.

## Quick Start

```bash
# Install dependencies
pip install fastapi uvicorn websockets

# Run the server
python main.py

# Open browser to http://localhost:8000
```

## What It Does

The simulation presents a brain-shaped neural network with 6 regions plus a central hub. It continuously runs learning trials where:

- **Input**: Neurons 1 and 2 in the Sensory region are stimulated together
- **Expected Output**: First half of Motor region neurons (OUT-1) should activate more than second half (OUT-2)
- **Learning**: Connections between co-active neurons strengthen over time (Hebbian learning)

## The Learning Task

```
INPUT:  [IN-1, IN-2, IN-3] = [1, 1, 0]
        ↓
        Sensory region neurons 0,1 stimulated
        ↓
        Signals propagate through network
        ↓
OUTPUT: OUT-1 (motor neurons 0-16) vs OUT-2 (motor neurons 17-34)

SUCCESS: OUT-1 > OUT-2 AND OUT-1 > 0.08 threshold
```

## How Learning Works

### Oja's Rule

The network uses Oja's learning rule, a stabilized form of Hebbian learning:

```
Δw = η · y · (x - y · w)

where:
  Δw = weight change
  η  = learning rate (0.03)
  x  = presynaptic (input) neuron activity
  y  = postsynaptic (output) neuron activity
  w  = current connection weight
```

**Key properties:**
- "Fire together, wire together" - co-active neurons strengthen their connection
- Self-normalizing - the `(x - y·w)` term prevents weights from exploding
- Weights decay slowly toward initial values when inactive

### Signal Flow

1. Input injected into Sensory region neurons
2. When neuron potential exceeds threshold (0.5), it fires
3. Firing sends pulses through outgoing connections
4. Connected neurons receive weighted input
5. Process cascades through the network

## Architecture

```
brain_sim/
├── main.py                 # FastAPI server
├── static/
│   ├── index.html          # Main page with HUD
│   ├── about.html          # Detailed explanation page
│   ├── css/
│   │   ├── base.css        # CSS variables, reset
│   │   ├── layout.css      # Container layout
│   │   ├── components.css  # Buttons, panels
│   │   ├── brain.css       # Brain viz, HUD styles
│   │   └── dashboard.css   # Dashboard panels, plots
│   └── js/
│       ├── config.js       # All tunable parameters
│       ├── utils.js        # Helper functions
│       ├── brain.js        # Brain shape renderer
│       ├── network.js      # Neurons, connections, regions
│       ├── learning.js     # Learning manager, trials
│       ├── renderer.js     # Network visualization
│       ├── dashboard.js    # Plots, stats display
│       └── main.js         # App initialization
└── simulation/             # Python backend (minimal)
```

## Brain Regions

| Region | Color | Function |
|--------|-------|----------|
| Sensory | Orange | Receives input signals |
| Motor | Yellow | Produces output (split into OUT-1/OUT-2) |
| Frontal | Cyan | Executive processing |
| Parietal | Blue | Spatial processing |
| Temporal | Green | Memory |
| Occipital | Magenta | Visual processing |
| Hub | Amber | Central integration |

## Controls

- **Play/Pause**: Start or stop the simulation
- **Reset**: Clear all activity and reset connection weights
- **Speed**: Adjust simulation speed (0.2x to 3x)

## Visualization Elements

### Learning HUD (Bottom Left)
- Circular progress ring showing success rate
- Trial counter
- Status indicator (IDLE/RUN/OK/FAIL)
- Last 5 trial results as bars

### Dashboard (Right Panel)
- **Current Trial**: Shows input pattern and output bar levels
- **Learning Curve**: Success rate over time (green line)
- **Learning Activity**: Weight change intensity per trial (orange line)
- **Region Activity**: Real-time activity levels per region

### Brain Visualization
- Neurons glow when active
- Faint colored trails show signal propagation
- Green/red lines show recently strengthened/weakened connections (subtle)

## Configuration

Key parameters in `static/js/config.js`:

```javascript
neurons: {
    countPerRegion: 35,
    decayRate: 0.04
},
connections: {
    intraRegionProbability: 0.15,
    hubConnectionProbability: 0.3,
    interRegionProbability: 0.05
},
learning: {
    learningRate: 0.02,
    decayRate: 0.01
}
```

## Current Limitations

1. **No directed pathway**: Connections are random, so there's no guaranteed sensory→motor(first half) path
2. **No teaching signal**: Pure Hebbian learning without reinforcement - the network doesn't "know" which output is correct
3. **Success may hover ~50%**: Without structural bias, both motor halves receive similar input

## Potential Improvements

- Add explicit sensory→motor(first half) connections to bootstrap learning
- Implement reward-modulated learning (reinforce when OUT-1 wins)
- Create separate Motor-A and Motor-B sub-regions with distinct connectivity

## License

MIT
